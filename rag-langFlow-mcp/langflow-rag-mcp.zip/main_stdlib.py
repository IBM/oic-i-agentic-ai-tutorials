#!/usr/bin/env python3
"""
MCP Server that exposes LangFlow RAG pipeline as a tool (stdlib only)
"""

import os
import json
import urllib.request
import urllib.parse
from mcp.server.fastmcp import FastMCP

# Initialize FastMCP server
mcp = FastMCP("langflow-rag-tool")

# Configuration from environment
LANGFLOW_API_URL = os.getenv("LANGFLOW_API_URL", "http://localhost:7860/api/v1")
LANGFLOW_FLOW_ID = os.getenv("LANGFLOW_FLOW_ID", "")


@mcp.tool("query_documents")
async def query_documents(question: str, top_k: int = 3) -> str:
    """
    Query your private documents using the LangFlow RAG pipeline.
    
    Args:
        question: The question to ask about your documents
        top_k: Number of relevant document chunks to retrieve (default: 3)
    
    Returns:
        A comprehensive answer based on retrieved documents
    """
    if not LANGFLOW_FLOW_ID:
        return "Error: LANGFLOW_FLOW_ID not configured. Please set it in environment variables."
    
    try:
        # Prepare payload
        payload = {
            "input_value": question,
            "tweaks": {
                "retriever": {"k": top_k}
            }
        }
        
        # Create request
        url = f"{LANGFLOW_API_URL}/run/{LANGFLOW_FLOW_ID}"
        data = json.dumps(payload).encode('utf-8')
        
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                'Content-Type': 'application/json',
                'Content-Length': str(len(data))
            }
        )
        
        # Make request
        with urllib.request.urlopen(req, timeout=30) as response:
            result = json.loads(response.read().decode('utf-8'))
        
        # Extract answer from response
        if "outputs" in result and len(result["outputs"]) > 0:
            answer = result["outputs"][0].get("text", "")
            return answer if answer else "No answer generated from LangFlow."
        else:
            return "No answer generated. Please check your LangFlow configuration."
            
    except urllib.error.URLError as e:
        return f"Error calling LangFlow API: {str(e)}"
    except json.JSONDecodeError as e:
        return f"Error parsing LangFlow response: {str(e)}"
    except Exception as e:
        return f"Unexpected error: {str(e)}"


if __name__ == "__main__":
    print("🚀 Starting LangFlow RAG MCP Tool server...")
    print(f"📡 LangFlow API: {LANGFLOW_API_URL}")
    print(f"🔑 Flow ID: {LANGFLOW_FLOW_ID or '⚠️  NOT SET - Please configure in environment'}")
    print("\nServer ready. Connect using MCP Inspector or watsonx Orchestrate.")
    mcp.run()
